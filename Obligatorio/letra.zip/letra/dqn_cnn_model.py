import torch.nn as nn
import torch.nn.functional as F

class DQN_CNN_Model(nn.Module):
    def __init__(self,  env_inputs, n_actions):
        # Implementar.

    def forward(self, env_input):
        # Implementar. 